#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "test.h"

/* fonction recursive, qui definit la zone de la couleur de la case i,j en parametre qui  met la couleur a -1 dans les cases deja visitees pour eviter une boucle infinie et qui remet la bonne couleur a la fin */
void trouve_zone_rec(int **M, int dim, int i, int j, int *taille, Liste *L)
{
  int couleur = M[i][j];
  //printf("couleur = %d\n", M[i][j]);
  //printf("%d\n", M[i][j]);
  //printf("%d\n", M[i+1][j]);
  Elnt_liste *actu;
  ajoute_en_tete(L,i,j);
  (*taille)++;

  while(M[i][j] == couleur){
    M[i][j] = -1;

  /* case de droite */
  if(i != (dim-1) && M[i+1][j] == couleur)
    {
      printf("droite, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i+1,j,taille,L);
    }

  /* case du bas */
  if (j != (dim-1) && M[i][j+1] == couleur)
    {
      printf("bas, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i,j+1,taille,L);
    }

  /* case de gauche */
  if (i != 0 && M[i-1][j] == couleur)
    {
      printf("gauche, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i-1,j,taille,L);
    }

  /* case du haut */
  if(j != 0 && M[i][j-1] == couleur)
    {
      printf("haut, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i,j-1,taille,L);
    }
  }
}

/* on stocke la couleur initiale avant de lancer notre fonction trouve_zone_rec puis apres avoir obtenu la zone on la recolorise a l aide de cette fonction */
void peint(int couleur, int **M, Liste *L)
{
  Elnt_liste *actu;
  actu = *L;
  while(actu != NULL){
    M[actu->i][actu->j] = couleur;
    actu = actu->suiv;
  }
}

/* joue avec une couleur aleatoire en appelant la fonction trouve_zone_rec et retourne le nombre de coups necessaires pour gagner
aff est un entier indiquant si il faut reafficher la grille ou non
nbcouleur est le nombre de changement de couleur et notre valeur de retour
*/
int sequence_aleatoire_rec(int **M, Grille *G, int dim, int nbcl, int aff){

  srand(time(NULL));
  int nbCoups = 0;
  printf("nbcl = %d\n", nbcl);
  
  /* On definit Zsg, la zone contenant la case situee en haut a gauche */
  Liste L;
  init_liste(&L);
  int taille = 1;
  int i, j;
  int couleur = M[0][0];
  trouve_zone_rec(M, dim, 0, 0, &taille, &L);
  peint(couleur,M,&L);
  printf("Couleur Zsg : %d \n",couleur);
  affiche_liste(&L,M);

  /* selectionne une couleur tant que la grille contient plus d'une couleur  */
  do{
    i = (int)(rand()%(G->dim));
    j = (int)(rand()%(G->dim));

    /* si la couleur selectionnee est differente de la couleur de Zsg */
    if(M[i][j] != couleur){
      couleur = M[i][j];
      printf("Couleur Zsg : %d\n", couleur);
      // printf("Couleur initiale : %d \n", M[i][j]);
      trouve_zone_rec(M,dim,i,j,&taille,&L);
      // printf("Couleur apres changement : %d \n",M[i][j]);
      peint(couleur,M,&L);
      // printf("Couleur finale : %d \n",M[i][j]);
      affiche_liste(&L,M);
      nbcl--; /* -----------------decrementation A REVOIR------------------ */
      printf("nbcl = %d\n", nbcl);
      nbCoups++;
      if(aff == 1){
	Grille_redessine_Grille();
	Grille_attente_touche();
      }
    }

  }while(nbcl > 1);
  
  printf("nbCoups = %d\n", nbCoups);
  return nbCoups;
}
