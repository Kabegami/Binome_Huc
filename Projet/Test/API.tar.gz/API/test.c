#include <stdio.h>
#include <stdlib.h>
#include "test.h"

/* fonction recursive, qui definit la zone de la couleur de la case i,j en parametre qui  met la couleur a -1 dans les cases deja visitees pour eviter une boucle infinie et qui remet la bonne couleur a la fin */
void trouve_zone_rec(int **M, int dim, int i, int j, int *taille, Liste *L)
{
  int couleur = M[i][j];
  //printf("couleur = %d\n", M[i][j]);
  //printf("%d\n", M[i][j]);
  //printf("%d\n", M[i+1][j]);
  Elnt_liste *actu;
  ajoute_en_tete(L,i,j);
  (*taille)++;

  while(M[i][j] == couleur){

    M[i][j] = -1;

  /* case de droite */
  if(i != (dim-1) && M[i+1][j] == couleur)
    {
      printf("droite, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i+1,j,taille,L);
    }

  /* case du bas */
  if (j != (dim-1) && M[i][j+1] == couleur)
    {
      printf("bas, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i,j+1,taille,L);
    }

  /* case de gauche */
  if (i != 0 && M[i-1][j] == couleur)
    {
      printf("gauche, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i-1,j,taille,L);
    }

  /* case du haut */
  if(j != 0 && M[i][j-1] == couleur)
    {
      printf("haut, taille = %d\n", *taille);
      trouve_zone_rec(M,dim,i,j-1,taille,L);
    }
  }
  
  /* remettre la bonne couleur */
  
}


int sequence_aleatoire_rec(int **M, Grille *G, int dim, int nbcl, int aff){







  
}
